# mikado
Template for potentialy first custom WordPress theme.
